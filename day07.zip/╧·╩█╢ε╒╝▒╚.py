import xlrd
wb = xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
sheet = wb.sheets()[1]
rows = sheet.nrows
cols = sheet.ncols
sheet_name = wb.sheet_names()

yearsum = 0
sum = 0
dt = {}
for m in range(0, 12):
    sheet = wb.sheet_by_index(m)
    rows = sheet.nrows
    cols = sheet.ncols
    for i in range(1, rows):
        name = sheet.row_values(i)[1]
        num = sheet.row_values(i)[5]
        if name in dt:
            if num in dt[name]:
                # 列表追加元素
                dt[name].append(num)
            else:
                # 字典新增元素
                dt[name]= [num]
        else:
            # 字典新增元素
            dt[name] = {name: [num]}

list=dt["小西装"]
list1=dt["衬衫"]
total=total1=0
for i in range(len(list)):
    total += list[i]
#print(total)
for i1 in range(len(list1)):
    total1 += list1[i1]
#print(total1)

a=dt["羽绒服"]
for a1 in a:
    a1=float(a1)
#print(a1)
b=dt["牛仔裤"]
for b1 in b:
    b1=float(b1)
#print(b1)
c=dt["风衣"]
for c1 in c:
    c1=float(c1)
#print(c1)
d=dt["皮草"]
for d1 in d:
    d1=float(d1)
#print(d1)
e=dt["T血"]
for e1 in e:
    e1=float(e1)
#print(e1)
''''''
f=dt["马甲"]["马甲"]
for f1 in f:
    f1=float(f1)
#print(f1)
g=dt["皮衣"]
for g1 in g:
    g1=float(g1)
#print(g1)
h=dt["休闲裤"]
for h1 in h:
    h1=float(h1)
#print(h1)
i=dt["卫衣"]
for i1 in i:
    i1=float(i1)
#print(i1)
j=dt["棉衣"]
for j1 in j:
    j1=float(j1)
#print(j1)
k=dt["铅笔裤"]
for k1 in k:
    k1=float(k1)
#print(k1)
sumz=a1+b1+c1+d1+e1+f1+g1+h1+j1+k1+total+total1
#print(round(sumz,2))
total11 = total/sumz
print("小西装占比为：%s"%round(total11,2))
total12=total1/sumz
print("衬衫占比为：%s"%round(total11,2))
a11=a1/sumz
print("羽绒服占比为：%s"%round(a11,2))
b11=b1/sumz
print("牛仔裤占比为：%s"%round(b11,2))
c11=c1/sumz
print("风衣占比为：%s"%round(c11,2))
d11=d1/sumz
print("皮草占比为：%s"%round(d11,2))
e11=e1/sumz
print("T恤占比为：%s"%round(e11,2))
f11=f1/sumz
print("马甲占比为：%s"%round(f11,2))
g11=g1/sumz
print("皮衣占比为：%s"%round(g11,2))
h11=h1/sumz
print("休闲裤占比为：%s"%round(h11,2))
i11=i1/sumz
print("卫衣占比为：%s"%round(i11,2))
j11=j1/sumz
print("棉衣占比为：%s"%round(j11,2))
k11=k1/sumz
print("铅笔裤占比为：%s"%round(k11,2))









