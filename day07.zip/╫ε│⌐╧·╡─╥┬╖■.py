import  xlrd
def sumSale(y,dict):
    wb = xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
    sum1 = sum2 = 0
    for x in range(1,13):
        sheet1=wb.sheet_by_index(x-1)
        nrows=sheet1.nrows

        for i in range (1,nrows):
            data = sheet1.row_values(i)
            sum1+=data[4]
            a=sheet1.cell_value(i,1)
            if a ==y:

                sum2+=data[4]


    dict[y]=sum2

    return dict
#
def each():
    wb = xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
    list1 = []
    for x in range(1,13):
        sheet1 = wb.sheet_by_index(x - 1)
        nrows = sheet1.nrows

        for i in range(1, nrows):
            data = sheet1.row_values(i)
            if data[1] not in list1:
                list1.append(data[1])
    return list1
dict={}
for i in each():
    sumSale(i,dict)
#print(dict,type(dict))
a=max(dict.values())
b=min(dict.values())
for i in dict:
    if dict[i]==a:
        print("全年销量最好的衣服是：%-5s销售%5s件" % (i, a))
    if dict[i]==b:
        print("全年销量最差的衣服是：%-5s销售%5s件" % (i, b))

print('——————————————————————————————————————————————————————————————————————————————————————————————')