import  xlrd
def sumS(b):
    wb = xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
    sum1 = sum2 = 0
    for a in range(1,13):
        sheet=wb.sheet_by_index(a-1)
        nrows=sheet.nrows

        for i in range (1,nrows):
            data = sheet.row_values(i)
            sum1+=data[4]
            if data[1] ==b:
                print(data[4], end="\t")
                sum2+=data[4]
    avg=(sum2/sum1)*100
    print(sum1,'\t',sum2)
    return b,avg
#
def each():
    wb = xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
    list1 = []
    for x in range(1,13):
        sheet1 = wb.sheet_by_index(x - 1)
        nrows = sheet1.nrows

        for i in range(1, nrows):
            data = sheet1.row_values(i)
            if data[1] not in list1:
                list1.append(data[1])
    return list1

for i in each():

    print('2020年%5s年销售件数占比%5.2f'%sumS(i),'%')
print('——————————————————————————————————————————————————————————————————————————————————————————————')