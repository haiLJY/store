'''
任务：
全年的销售总额
每件衣服的销售（件数）占比
每件衣服的月销售占比
每件衣服的销售额占比
最畅销的衣服是那种
每个季度最畅销的衣服
全年销量最低的衣服
'''
import xlrd
wb = xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
Ssum = 0
sum = 0
for m in range(0, 12):
    sheet = wb.sheet_by_index(m)
    rows = sheet.nrows
    cols = sheet.ncols
    for i in range(1, rows):
        data = sheet.row_values(i)
        total = data[2] * data[4]
        sum += total
    print(m+1, "月销售总额为￥", round(sum, 2))
Ssum += sum
print("全年的销售总额为￥", round(Ssum, 2))
'''
import  xlrd
def sumS(a):
    wb=xlrd.open_workbook(filename=r"D:\Python自动化测试\python\python\day07\2020年每个月的销售情况.xlsx")
    sheet=wb.sheet_by_index(a)
    nrows=sheet.nrows
        sum=0
    for i in range (1,nrows):
        data = sheet.row_values(i)
        total = data[2] * data[4]
        sum += total
    return(sum)

zong=sumS(0)+sumS(1)+sumS(2)+sumS(3)+sumS(4)+sumS(5)+sumS(6)+sumS(7)+sumS(8)+sumS(9)+sumS(10)+sumS(11)
print("2020年全年总营业额：%8.2f"%zong)
'''








